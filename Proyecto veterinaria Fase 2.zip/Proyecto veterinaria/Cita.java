package proyectoveterinaria

public class Cita {

    private int id;
    private String fecha;
    private String hora;
    private String motivo;
    private String estado;

    private Mascota mascota;
    private Veterinario veterinario;

    public Cita(int id, String fecha, String hora,
                String motivo, Mascota mascota,
                Veterinario veterinario) {

        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.mascota = mascota;
        this.veterinario = veterinario;
        this.estado = "Programada";
    }

    public void cancelar() {
        estado = "Cancelada";
    }

    public void completar() {
        estado = "Completada";
    }

    public void mostrarInformacion() {
        System.out.println("=== CITA ===");
        System.out.println("ID: " + id);
        System.out.println("Fecha: " + fecha);
        System.out.println("Hora: " + hora);
        System.out.println("Motivo: " + motivo);
        System.out.println("Estado: " + estado);
        System.out.println("Mascota: " + mascota.getNombre());
        System.out.println("Veterinario: " + veterinario.getNombre());
    }
        public void mostrarInformacion() {

    }

    public int getId() {
        return id;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getEstado() {
        return estado;
    }
}

