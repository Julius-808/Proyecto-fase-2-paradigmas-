package proyectoveterinaria

public class Tratamiento {

    private int id;
    private String nombre;
    private String descripcion;
    private int duracionDias;
    private String indicaciones;

    public Tratamiento(int id, String nombre, String descripcion,
                       int duracionDias, String indicaciones) {

        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.duracionDias = duracionDias;
        this.indicaciones = indicaciones;
    }

    public void mostrarInformacion() {
        System.out.println("=== TRATAMIENTO ===");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Descripcion: " + descripcion);
        System.out.println("Duracion: " + duracionDias + " dias");
        System.out.println("Indicaciones: " + indicaciones);
    }

    public String getNombre() {
        return nombre;
    }
}