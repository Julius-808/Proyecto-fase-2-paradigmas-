package proyectoveterinaria

public class Veterinario extends Persona {

    private String especialidad;
    private String numeroLicencia;

    public Veterinario(String nombre, String documento, String telefono,
                       String correo, String especialidad,
                       String numeroLicencia) {

        super(nombre, documento, telefono, correo);

        this.especialidad = especialidad;
        this.numeroLicencia = numeroLicencia;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }

    public void atenderMascota(Mascota mascota) {
        System.out.println(
            "El veterinario " + getNombre()
            + " esta atendiendo a " + mascota.getNombre()
        );
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("=== VETERINARIO ===");
        super.mostrarInformacion();
        System.out.println("Especialidad: " + especialidad);
        System.out.println("Numero de licencia: " + numeroLicencia);
    }
}