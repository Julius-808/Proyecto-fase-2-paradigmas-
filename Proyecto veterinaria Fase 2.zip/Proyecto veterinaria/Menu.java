package proyectoveterinaria;

import java.util.Scanner;

public class Menu {

    private Veterinaria veterinaria;
    private Scanner scanner;

    public Menu(Veterinaria veterinaria) {
        this.veterinaria = veterinaria;
        this.scanner = new Scanner(System.in);
    }

    public void mostrar() {
        int opcion;

        do {
            System.out.println();
            System.out.println("=== VETERINARIA AMIGOS PELUDOS ===");
            System.out.println("1. Mostrar clientes");
            System.out.println("2. Mostrar mascotas");
            System.out.println("3. Mostrar citas");
            System.out.println("4. Ordenar mascotas por nombre (Merge Sort)");
            System.out.println("5. Ordenar clientes por nombre (Merge Sort)");
            System.out.println("6. Ordenar citas por fecha y hora (Shell Sort)");
            System.out.println("7. Registrar cliente");
            System.out.println("8. Registrar mascota");
            System.out.println("9. Programar cita");
            System.out.println("0. Salir");
            System.out.print("Elija una opcion: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    veterinaria.mostrarClientes();
                    break;

                case 2:
                    veterinaria.mostrarMascotas();
                    break;

                case 3:
                    veterinaria.mostrarCitas();
                    break;

                case 4:
                    Ordenamiento.mergeSortMascotas(veterinaria.getMascotas());
                    System.out.println("Mascotas ordenadas por nombre:");
                    veterinaria.mostrarMascotas();
                    break;

                case 5:
                    Ordenamiento.mergeSortClientes(veterinaria.getClientes());
                    System.out.println("Clientes ordenados por nombre:");
                    veterinaria.mostrarClientes();
                    break;

                case 6:
                    Ordenamiento.shellSortCitas(veterinaria.getCitas());
                    System.out.println("Citas ordenadas por fecha y hora:");
                    veterinaria.mostrarCitas();
                    break;

                case 7:
                    registrarCliente();
                    break;

                case 8:
                    registrarMascota();
                    break;

                case 9:
                    programarCita();
                    break;

                case 0:
                    System.out.println("Hasta pronto!");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }

        } while (opcion != 0);
    }

    private void registrarCliente() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Documento: ");
        String documento = scanner.nextLine();
        System.out.print("Telefono: ");
        String telefono = scanner.nextLine();
        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        Cliente cliente = new Cliente(nombre, documento, telefono, correo);
        veterinaria.registrarCliente(cliente);
        System.out.println("Cliente registrado.");
    }

    private void registrarMascota() {
        if (veterinaria.getClientes().isEmpty()) {
            System.out.println("Primero debe registrar un cliente.");
            return;
        }

        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Especie: ");
        String especie = scanner.nextLine();
        System.out.print("Raza: ");
        String raza = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Peso: ");
        double peso = scanner.nextDouble();
        scanner.nextLine();

        Mascota mascota = new Mascota(id, nombre, especie, raza, edad, peso);

        System.out.println("Clientes registrados:");
        for (int i = 0; i < veterinaria.getClientes().size(); i++) {
            System.out.println((i + 1) + ". " + veterinaria.getClientes().get(i).getNombre());
        }
        System.out.print("A cual cliente pertenece? (numero): ");
        int indice = scanner.nextInt();
        scanner.nextLine();

        if (indice >= 1 && indice <= veterinaria.getClientes().size()) {
            veterinaria.getClientes().get(indice - 1).agregarMascota(mascota);
            veterinaria.registrarMascota(mascota);
            System.out.println("Mascota registrada.");
        } else {
            System.out.println("Cliente no valido.");
        }
    }

    private void programarCita() {
        if (veterinaria.getMascotas().isEmpty() || veterinaria.getVeterinarios().isEmpty()) {
            System.out.println("Debe haber al menos una mascota y un veterinario.");
            return;
        }

        System.out.print("ID de la cita: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Fecha (dd/mm/aaaa): ");
        String fecha = scanner.nextLine();
        System.out.print("Hora (hh:mm): ");
        String hora = scanner.nextLine();
        System.out.print("Motivo: ");
        String motivo = scanner.nextLine();

        System.out.println("Mascotas:");
        for (int i = 0; i < veterinaria.getMascotas().size(); i++) {
            System.out.println((i + 1) + ". " + veterinaria.getMascotas().get(i).getNombre());
        }
        System.out.print("Elija la mascota: ");
        int indiceMascota = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Veterinarios:");
        for (int i = 0; i < veterinaria.getVeterinarios().size(); i++) {
            System.out.println((i + 1) + ". " + veterinaria.getVeterinarios().get(i).getNombre());
        }
        System.out.print("Elija el veterinario: ");
        int indiceVet = scanner.nextInt();
        scanner.nextLine();

        if (indiceMascota >= 1 && indiceMascota <= veterinaria.getMascotas().size()
                && indiceVet >= 1 && indiceVet <= veterinaria.getVeterinarios().size()) {

            Cita cita = new Cita(
                    id,
                    fecha,
                    hora,
                    motivo,
                    veterinaria.getMascotas().get(indiceMascota - 1),
                    veterinaria.getVeterinarios().get(indiceVet - 1)
            );

            veterinaria.programarCita(cita);
            System.out.println("Cita programada.");
        } else {
            System.out.println("Opcion no valida.");
        }
    }
}
