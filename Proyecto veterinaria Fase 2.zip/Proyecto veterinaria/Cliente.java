package proyectoveterinaria

import java.util.ArrayList;

public class Cliente extends Persona {

    private ArrayList<Mascota> mascotas;

    public Cliente(String nombre, String documento, String telefono, String correo) {
        super(nombre, documento, telefono, correo);
        mascotas = new ArrayList<>();
    }

    public void agregarMascota(Mascota mascota) {
        mascotas.add(mascota);
    }

    public ArrayList<Mascota> getMascotas() {
        return mascotas;
    }

    public void mostrarMascotas() {
        System.out.println("Mascotas de " + getNombre() + ":");

        for (Mascota mascota : mascotas) {
            System.out.println("- " + mascota.getNombre());
        }
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("=== CLIENTE ===");
        super.mostrarInformacion();
        System.out.println("Cantidad de mascotas: " + mascotas.size());
    }
}



