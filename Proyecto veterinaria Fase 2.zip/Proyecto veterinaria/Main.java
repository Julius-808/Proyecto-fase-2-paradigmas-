package proyectoveterinaria

public class Main {

    public static void main(String[] args) {

        // Crear la veterinaria
        Veterinaria veterinaria =
                new Veterinaria(
                        "Veterinaria Amigos Peludos",
                        "Calle 10 #20-30"
                );

        // Crear un cliente
        Cliente cliente =
                new Cliente(
                        "Carlos Perez",
                        "123456789",
                        "3001234567",
                        "carlos@gmail.com"
                );

        // Crear un veterinario
        Veterinario veterinario =
                new Veterinario(
                        "Laura Gomez",
                        "987654321",
                        "3109876543",
                        "laura@veterinaria.com",
                        "Medicina general",
                        "VET-12345"
                );

        // Crear una mascota
        Mascota mascota =
                new Mascota(
                        1,
                        "Max",
                        "Perro",
                        "Labrador",
                        5,
                        25.5
                );

        // Relacionar mascota con cliente
        cliente.agregarMascota(mascota);

        // Registrar información en la veterinaria
        veterinaria.registrarCliente(cliente);
        veterinaria.registrarVeterinario(veterinario);
        veterinaria.registrarMascota(mascota);

        // Crear una cita
        Cita cita =
                new Cita(
                        1,
                        "30/08/2026",
                        "10:00",
                        "Revision general",
                        mascota,
                        veterinario
                );

        veterinaria.programarCita(cita);

        // Crear una consulta
        Consulta consulta =
                new Consulta(
                        1,
                        "30/08/2026",
                        "Inflamacion leve",
                        "Se recomienda reposo",
                        mascota,
                        veterinario
                );

        // Crear tratamiento
        Tratamiento tratamiento =
                new Tratamiento(
                        1,
                        "Antiinflamatorio",
                        "Medicamento para reducir la inflamacion",
                        5,
                        "Administrar segun indicacion veterinaria"
                );

        
        consulta.agregarTratamiento(tratamiento);
        
        Menu menu = new Menu(veterinaria);
        menu.mostrar();

       
    }
}