
    public static void mergeSortClientes(ArrayList<Cliente> lista) {
        if (lista.size() <= 1) {
            return;
        }

        int medio = lista.size() / 2;

        ArrayList<Cliente> izquierda = new ArrayList<>(lista.subList(0, medio));
        ArrayList<Cliente> derecha = new ArrayList<>(lista.subList(medio, lista.size()));

        mergeSortClientes(izquierda);
        mergeSortClientes(derecha);

        mezclarClientes(lista, izquierda, derecha);
    }

    private static void mezclarClientes(ArrayList<Cliente> lista,
                                        ArrayList<Cliente> izquierda,
                                        ArrayList<Cliente> derecha) {
        int i = 0, j = 0, k = 0;

        while (i < izquierda.size() && j < derecha.size()) {
            if (izquierda.get(i).getNombre()
                    .compareToIgnoreCase(derecha.get(j).getNombre()) <= 0) {
                lista.set(k, izquierda.get(i));
                i++;
            } else {
                lista.set(k, derecha.get(j));
                j++;
            }
            k++;
        }

        while (i < izquierda.size()) {
            lista.set(k, izquierda.get(i));
            i++;
            k++;
        }

        while (j < derecha.size()) {
            lista.set(k, derecha.get(j));
            j++;
            k++;
        }
    }

    
    public static void shellSortCitas(ArrayList<Cita> lista) {
        int n = lista.size();

        for (int salto = n / 2; salto > 0; salto /= 2) {
            for (int i = salto; i < n; i++) {
                Cita actual = lista.get(i);
                int j = i;

                while (j >= salto && compararCitas(lista.get(j - salto), actual) > 0) {
                    lista.set(j, lista.get(j - salto));
                    j -= salto;
                }

                lista.set(j, actual);
            }
        }
    }

    
    private static int compararCitas(Cita a, Cita b) {
        int comparacionFecha = compararFechas(a.getFecha(), b.getFecha());

        if (comparacionFecha != 0) {
            return comparacionFecha;
        }

        return a.getHora().compareTo(b.getHora());
    }

    
    private static String convertirFecha(String fecha) {
        String[] partes = fecha.split("/");
        return partes[2] + partes[1] + partes[0];
    }

    private static int compararFechas(String fechaA, String fechaB) {
        return convertirFecha(fechaA).compareTo(convertirFecha(fechaB));
    }
}
