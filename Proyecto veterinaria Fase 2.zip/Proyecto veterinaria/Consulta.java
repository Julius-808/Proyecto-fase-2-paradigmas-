package proyectoveterinaria
import java.util.ArrayList;

public class Consulta {

    private int id;
    private String fecha;
    private String diagnostico;
    private String observaciones;

    private Mascota mascota;
    private Veterinario veterinario;

    private ArrayList<Tratamiento> tratamientos;

    public Consulta(int id, String fecha, String diagnostico,
                    String observaciones, Mascota mascota,
                    Veterinario veterinario) {

        this.id = id;
        this.fecha = fecha;
        this.diagnostico = diagnostico;
        this.observaciones = observaciones;
        this.mascota = mascota;
        this.veterinario = veterinario;

        tratamientos = new ArrayList<>();
    }

    public void agregarTratamiento(Tratamiento tratamiento) {
        tratamientos.add(tratamiento);
    }

    public void mostrarInformacion() {

        System.out.println("=== CONSULTA ===");

        System.out.println("ID: " + id);
        System.out.println("Fecha: " + fecha);
        System.out.println("Mascota: " + mascota.getNombre());
        System.out.println("Veterinario: " + veterinario.getNombre());
        System.out.println("Diagnostico: " + diagnostico);
        System.out.println("Observaciones: " + observaciones);

        System.out.println("Tratamientos:");

        for (Tratamiento tratamiento : tratamientos) {
            System.out.println("- " + tratamiento.getNombre());
        }
    }
}