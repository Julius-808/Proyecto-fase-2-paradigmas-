package proyectoveterinaria
import java.util.ArrayList;

public class Veterinaria {

    private String nombre;
    private String direccion;

    private ArrayList<Cliente> clientes;
    private ArrayList<Veterinario> veterinarios;
    private ArrayList<Mascota> mascotas;
    private ArrayList<Cita> citas;

    public Veterinaria(String nombre, String direccion) {

        this.nombre = nombre;
        this.direccion = direccion;

        clientes = new ArrayList<>();
        veterinarios = new ArrayList<>();
        mascotas = new ArrayList<>();
        citas = new ArrayList<>();
    }

    public void registrarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void registrarVeterinario(Veterinario veterinario) {
        veterinarios.add(veterinario);
    }

    public void registrarMascota(Mascota mascota) {
        mascotas.add(mascota);
    }

    public void programarCita(Cita cita) {
        citas.add(cita);
    }

    public void mostrarClientes() {

        System.out.println("=== CLIENTES ===");

        for (Cliente cliente : clientes) {
            System.out.println(cliente.getNombre());
        }
    }

    public void mostrarVeterinarios() {

        System.out.println("=== VETERINARIOS ===");

        for (Veterinario veterinario : veterinarios) {
            System.out.println(veterinario.getNombre());
        }
    }

    public void mostrarMascotas() {

        System.out.println("=== MASCOTAS ===");

        for (Mascota mascota : mascotas) {
            System.out.println(
                mascota.getNombre() +
                " - " +
                mascota.getEspecie()
            );
        }
    }

    public void mostrarCitas() {

        System.out.println("=== CITAS ===");

        for (Cita cita : citas) {
            cita.mostrarInformacion();
            System.out.println();
        }
    }
        public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public ArrayList<Veterinario> getVeterinarios() {
        return veterinarios;
    }

    public ArrayList<Mascota> getMascotas() {
        return mascotas;
    }

    public ArrayList<Cita> getCitas() {
        return citas;
    }
}

